import * as AWS from 'aws-sdk'

const configuration = {
    region: 'us-east-1'
}

AWS.config.update(configuration)

const docClient = new AWS.DynamoDB.DocumentClient()

export const putData = (tableName , data) => {
    data.id = String(Date.now())

    var params = {
        TableName: tableName,
        Item: data
    }
    
    docClient.put(params, function (err, data) {
        if (err) {
            console.log('Error', err)
        } else {
            console.log('Success', data)
        }
    })
}

export const fetchData = (tableName) => {
    var params = {
        TableName: tableName
    }

    return docClient.scan(params).promise()
}
